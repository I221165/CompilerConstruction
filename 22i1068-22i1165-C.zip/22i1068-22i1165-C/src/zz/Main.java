package zz;

import java.util.*;

// ============================================================================
// 1. NFA Construction
// ============================================================================

class State implements Comparable<State> {
    static int nextId = 0;
    int id;
    boolean isFinal;
    Map<Character, List<State>> transitions;

    public State() {
        this.id = nextId++;
        this.isFinal = false;
        this.transitions = new HashMap<>();
    }

    public void addTransition(Character symbol, State state) {
        transitions.computeIfAbsent(symbol, k -> new ArrayList<>()).add(state);
    }

    @Override
    public int compareTo(State other) {
        return Integer.compare(this.id, other.id);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof State)) return false;
        State s = (State) o;
        return this.id == s.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}

class NFA {
    State start;
    State end;

    public NFA(State start, State end) {
        this.start = start;
        this.end = end;
    }
}

// ============================================================================
// 2. Regex Parser (Thompson’s Construction)
// ============================================================================

/*
   This regex parser supports:
   - Grouping with parentheses.
   - Alternation using "|" (union).
   - Kleene star (*) and plus operator (+).
   - Character classes (e.g., [a-z]) and negated classes (e.g., [^'\\]).
   - Escaped characters.
*/
class RegexParser {
    private String regex;
    private int pos;

    public RegexParser(String regex) {
        this.regex = regex;
        this.pos = 0;
    }

    public NFA parse() {
        NFA nfa = expression();
        if (pos < regex.length()) {
            throw new RuntimeException("Unexpected character at end: " + regex.charAt(pos));
        }
        return nfa;
    }

    // expression : term ('|' term)*
    private NFA expression() {
        NFA termNFA = term();
        while (peek() != null && peek() == '|') {
            consume(); // consume '|'
            NFA term2 = term();
            termNFA = union(termNFA, term2);
        }
        return termNFA;
    }

    // term : factor+
    private NFA term() {
        NFA nfa = factor();
        while (peek() != null && peek() != '|' && peek() != ')') {
            NFA nextFactor = factor();
            nfa = concatenate(nfa, nextFactor);
        }
        return nfa;
    }

    // factor : base ( '*' | '+' )*
    private NFA factor() {
        NFA baseNfa = base();
        while (peek() != null && (peek() == '*' || peek() == '+')) {
            char op = consume();
            if (op == '*') {
                baseNfa = kleeneClosure(baseNfa);
            } else if (op == '+') {
                // A+ = A concatenated with A*
                NFA cloned = cloneNFA(baseNfa);
                baseNfa = concatenate(baseNfa, kleeneClosure(cloned));
            }
        }
        return baseNfa;
    }

    // base : literal | '(' expression ')' | character class | escape sequence
    private NFA base() {
        Character c = peek();
        if (c == null) {
            throw new RuntimeException("Unexpected end of regex");
        }
        if (c == '(') {
            consume(); // consume '('
            NFA nfa = expression();
            if (peek() == null || peek() != ')') {
                throw new RuntimeException("Missing closing parenthesis");
            }
            consume(); // consume ')'
            return nfa;
        } else if (c == '[') {
            return parseCharacterClass();
        } else if (c == '\\') {
            consume(); // consume '\'
            if (peek() == null) {
                throw new RuntimeException("Incomplete escape sequence");
            }
            char literal = consume();
            return literal(literal);
        } else {
            return literal(consume());
        }
    }

    // Parse a character class. Supports both normal and negated classes.
    private NFA parseCharacterClass() {
        if (consume() != '[') {
            throw new RuntimeException("Expected '[' at beginning of character class");
        }
        boolean negated = false;
        if (peek() != null && peek() == '^') {
            negated = true;
            consume(); // consume '^'
        }
        List<Character> charsInClass = new ArrayList<>();
        // Parse one or more characters or ranges until ']'
        while (peek() != null && peek() != ']') {
            char startChar = consume();
            if (peek() != null && peek() == '-') {
                consume(); // consume '-'
                if (peek() == null || peek() == ']') {
                    throw new RuntimeException("Invalid range in character class");
                }
                char endChar = consume();
                for (char ch = startChar; ch <= endChar; ch++) {
                    charsInClass.add(ch);
                }
            } else {
                charsInClass.add(startChar);
            }
        }
        if (peek() == null || consume() != ']') {
            throw new RuntimeException("Expected ']' at end of character class");
        }
        List<Character> allowedChars;
        if (negated) {
            // Allow all printable ASCII except those in charsInClass.
            allowedChars = new ArrayList<>();
            for (char c = 32; c < 127; c++) {
                if (!charsInClass.contains(c)) {
                    allowedChars.add(c);
                }
            }
        } else {
            allowedChars = charsInClass;
        }
        NFA result = null;
        for (char ch : allowedChars) {
            NFA charNFA = literal(ch);
            if (result == null) {
                result = charNFA;
            } else {
                result = union(result, charNFA);
            }
        }
        if (result == null) {
            throw new RuntimeException("Empty character class");
        }
        return result;
    }

    // Create an NFA for a single literal character.
    private NFA literal(char c) {
        State start = new State();
        State end = new State();
        start.addTransition(c, end);
        end.isFinal = true;
        return new NFA(start, end);
    }

    // Alternation (union) of two NFAs.
    private NFA union(NFA nfa1, NFA nfa2) {
        State start = new State();
        State end = new State();
        start.addTransition(null, nfa1.start);
        start.addTransition(null, nfa2.start);
        nfa1.end.addTransition(null, end);
        nfa2.end.addTransition(null, end);
        nfa1.end.isFinal = false;
        nfa2.end.isFinal = false;
        end.isFinal = true;
        return new NFA(start, end);
    }

    // Concatenation of two NFAs.
    private NFA concatenate(NFA nfa1, NFA nfa2) {
        nfa1.end.addTransition(null, nfa2.start);
        nfa1.end.isFinal = false;
        return new NFA(nfa1.start, nfa2.end);
    }

    // Kleene closure (zero or more repetitions) of an NFA.
    private NFA kleeneClosure(NFA nfa) {
        State start = new State();
        State end = new State();
        start.addTransition(null, nfa.start);
        start.addTransition(null, end);
        nfa.end.addTransition(null, nfa.start);
        nfa.end.addTransition(null, end);
        nfa.end.isFinal = false;
        end.isFinal = true;
        return new NFA(start, end);
    }

    private Character peek() {
        if (pos >= regex.length()) return null;
        return regex.charAt(pos);
    }

    private char consume() {
        return regex.charAt(pos++);
    }

    // Clone an NFA (sufficient for our literals/character classes).
    private NFA cloneNFA(NFA original) {
        Map<State, State> map = new HashMap<>();
        cloneState(original.start, map);
        return new NFA(map.get(original.start), map.get(original.end));
    }

    private void cloneState(State s, Map<State, State> map) {
        if (map.containsKey(s)) return;
        State copy = new State();
        copy.isFinal = s.isFinal;
        map.put(s, copy);
        for (Map.Entry<Character, List<State>> entry : s.transitions.entrySet()) {
            for (State target : entry.getValue()) {
                cloneState(target, map);
                copy.addTransition(entry.getKey(), map.get(target));
            }
        }
    }
}

// ============================================================================
// 3. NFA to DFA Conversion (Subset Construction)
// ============================================================================

class DFAState {
    Set<State> nfaStates;
    boolean isFinal;
    Map<Character, DFAState> transitions;
    int id;

    public DFAState(Set<State> nfaStates, int id) {
        this.nfaStates = nfaStates;
        this.id = id;
        this.isFinal = false;
        for (State s : nfaStates) {
            if (s.isFinal) {
                this.isFinal = true;
                break;
            }
        }
        this.transitions = new HashMap<>();
    }
}

class DFA {
    DFAState start;
    List<DFAState> states;

    public DFA(DFAState start, List<DFAState> states) {
        this.start = start;
        this.states = states;
    }

    // Simulate the DFA starting at startPos; return length of longest match.
    public int match(String input, int startPos) {
        DFAState current = start;
        int pos = startPos;
        int lastAccept = -1;
        while (pos < input.length()) {
            char c = input.charAt(pos);
            if (current.transitions.containsKey(c)) {
                current = current.transitions.get(c);
                pos++;
                if (current.isFinal) {
                    lastAccept = pos - startPos;
                }
            } else {
                break;
            }
        }
        return lastAccept;
    }

    public void displayTransitionTable() {
        System.out.println("DFA Transition Table:");
        for (DFAState state : states) {
            System.out.print("State " + state.id + (state.isFinal ? " (final): " : ": "));
            for (Map.Entry<Character, DFAState> entry : state.transitions.entrySet()) {
                System.out.print("[" + entry.getKey() + " -> " + entry.getValue().id + "] ");
            }
            System.out.println();
        }
    }
}

class NfaToDfaConverter {
    private int dfaStateId = 0;

    private Set<State> epsilonClosure(Set<State> states) {
        Set<State> closure = new TreeSet<>(states);
        Stack<State> stack = new Stack<>();
        for (State s : states) {
            stack.push(s);
        }
        while (!stack.isEmpty()) {
            State s = stack.pop();
            List<State> epsTransitions = s.transitions.get(null);
            if (epsTransitions != null) {
                for (State t : epsTransitions) {
                    if (!closure.contains(t)) {
                        closure.add(t);
                        stack.push(t);
                    }
                }
            }
        }
        return closure;
    }

    private Set<State> move(Set<State> states, char symbol) {
        Set<State> result = new TreeSet<>();
        for (State s : states) {
            List<State> trans = s.transitions.get(symbol);
            if (trans != null) {
                result.addAll(trans);
            }
        }
        return result;
    }

    public DFA convert(NFA nfa) {
        List<DFAState> dfaStates = new ArrayList<>();
        Map<Set<State>, DFAState> mapping = new HashMap<>();

        Set<State> startSet = epsilonClosure(new TreeSet<>(Arrays.asList(nfa.start)));
        DFAState startDfa = new DFAState(startSet, dfaStateId++);
        dfaStates.add(startDfa);
        mapping.put(startSet, startDfa);

        Queue<DFAState> queue = new LinkedList<>();
        queue.add(startDfa);

        while (!queue.isEmpty()) {
            DFAState current = queue.poll();
            for (char c = 32; c < 127; c++) {  // iterate over printable ASCII
                Set<State> moveSet = move(current.nfaStates, c);
                if (moveSet.isEmpty()) continue;
                Set<State> nextSet = epsilonClosure(moveSet);
                DFAState nextDfa = mapping.get(nextSet);
                if (nextDfa == null) {
                    nextDfa = new DFAState(nextSet, dfaStateId++);
                    mapping.put(nextSet, nextDfa);
                    dfaStates.add(nextDfa);
                    queue.add(nextDfa);
                }
                current.transitions.put(c, nextDfa);
            }
        }
        return new DFA(startDfa, dfaStates);
    }
}

// ============================================================================
// 4. Token Definitions and Lexical Analyzer
// ============================================================================

// Extended TokenType to include KEYWORDS.
enum TokenType {
    KEYWORDS, COMMENT, CHARACTER, FLOAT, INTEGER, BOOLEAN, OPERATOR, PUNCTUATION, IDENTIFIER, WHITESPACE, UNKNOWN
}

class Token {
    TokenType type;
    String lexeme;
    int line;

    public Token(TokenType type, String lexeme, int line) {
        this.type = type;
        this.lexeme = lexeme;
        this.line = line;
    }

    @Override
    public String toString() {
        return "Token{" + "type=" + type + ", lexeme='" + lexeme + '\'' + ", line=" + line + '}';
    }
}

class TokenDefinition {
    TokenType type;
    String pattern;
    NFA nfa;
    DFA dfa;

    public TokenDefinition(TokenType type, String pattern) {
        this.type = type;
        this.pattern = pattern;
    }

    public void compile() {
        RegexParser parser = new RegexParser(pattern);
        nfa = parser.parse();
        NfaToDfaConverter converter = new NfaToDfaConverter();
        dfa = converter.convert(nfa);
    }
}

class Lexer {
    String input;
    int pos;
    int line;
    List<TokenDefinition> tokenDefs;
    ErrorHandler errorHandler;

    public Lexer(String input, List<TokenDefinition> tokenDefs, ErrorHandler errorHandler) {
        this.input = input;
        this.pos = 0;
        this.line = 1;
        this.tokenDefs = tokenDefs;
        this.errorHandler = errorHandler;
    }

    public List<Token> tokenize() {
        List<Token> tokens = new ArrayList<>();
        while (pos < input.length()) {
            // Skip extra spaces.
            if (Character.isWhitespace(input.charAt(pos))) {
                if (input.charAt(pos) == '\n') {
                    line++;
                }
                pos++;
                continue;
            }
            int maxLen = -1;
            TokenDefinition bestDef = null;
            for (TokenDefinition def : tokenDefs) {
                if (def.dfa == null) continue; // skip those that failed to compile
                int len = def.dfa.match(input, pos);
                if (len > maxLen) {
                    maxLen = len;
                    bestDef = def;
                }
            }
            if (maxLen > 0 && bestDef != null) {
                String lexeme = input.substring(pos, pos + maxLen);
                tokens.add(new Token(bestDef.type, lexeme, line));
                for (int i = 0; i < lexeme.length(); i++) {
                    if (lexeme.charAt(i) == '\n') {
                        line++;
                    }
                }
                pos += maxLen;
            } else {
                errorHandler.reportError("Unrecognized token: " + input.charAt(pos), line);
                pos++;
            }
        }
        return tokens;
    }
}

// ============================================================================
// 5. Symbol Table, Scope Manager, and Error Handler
// ============================================================================

class SymbolTableEntry {
    String name;
    String type;
    String scope;
    int memoryAddress;

    public SymbolTableEntry(String name, String type, String scope, int memoryAddress) {
        this.name = name;
        this.type = type;
        this.scope = scope;
        this.memoryAddress = memoryAddress;
    }

    @Override
    public String toString() {
        return "Entry{name='" + name + "', type='" + type + "', scope='" + scope + "', address=" + memoryAddress + "}";
    }
}

class SymbolTable {
    Map<String, SymbolTableEntry> table;

    public SymbolTable() {
        table = new HashMap<>();
    }

    public void addEntry(String name, String type, String scope, int memoryAddress) {
        table.put(name, new SymbolTableEntry(name, type, scope, memoryAddress));
    }

    public SymbolTableEntry lookup(String name) {
        return table.get(name);
    }

    public void display() {
        System.out.println("Symbol Table:");
        for (SymbolTableEntry entry : table.values()) {
            System.out.println(entry);
        }
    }
}

// A simple scope manager using a stack of symbol tables.
class ScopeManager {
    private Stack<SymbolTable> scopeStack;

    public ScopeManager() {
        scopeStack = new Stack<>();
        // Push the global scope.
        scopeStack.push(new SymbolTable());
    }

    public void pushScope() {
        scopeStack.push(new SymbolTable());
    }

    public void popScope() {
        if (scopeStack.size() > 1) {
            scopeStack.pop();
        } else {
            System.err.println("Cannot pop the global scope!");
        }
    }

    public SymbolTable currentScope() {
        return scopeStack.peek();
    }

    public void addEntry(String name, String type, int memoryAddress) {
        String scope = (scopeStack.size() == 1) ? "global" : "local";
        currentScope().addEntry(name, type, scope, memoryAddress);
    }

    public void displayScopes() {
        System.out.println("Global Scope:");
        scopeStack.firstElement().display();
        if (scopeStack.size() > 1) {
            System.out.println("Local Scopes:");
            for (int i = 1; i < scopeStack.size(); i++) {
                System.out.println("Scope Level " + i + ":");
                scopeStack.get(i).display();
            }
        }
    }
}

class ErrorHandler {
    List<String> errors;

    public ErrorHandler() {
        errors = new ArrayList<>();
    }

    public void reportError(String message, int line) {
        String errorMsg = "Error at line " + line + ": " + message;
        errors.add(errorMsg);
        System.err.println(errorMsg);
    }

    public boolean hasErrors() {
        return !errors.isEmpty();
    }

    public void displayErrors() {
        for (String err : errors) {
            System.err.println(err);
        }
    }
}

// ============================================================================
// 6. Main Compiler Class (Integration)
// ============================================================================

public class Main {
    public static void main(String[] args) {
        List<TokenDefinition> tokenDefs = new ArrayList<>();
        // IMPORTANT: Place KEYWORDS before IDENTIFIER so that keywords are recognized.
        tokenDefs.add(new TokenDefinition(TokenType.KEYWORDS, "(int|float|char|bool)"));
        // COMMENT token supports single-line and multi-line comments.
        tokenDefs.add(new TokenDefinition(TokenType.COMMENT, "(//.*|/\\*([^*]|\\*+[^*/])*\\*+/)"));
        tokenDefs.add(new TokenDefinition(TokenType.CHARACTER, "('([^'\\\\]|\\\\.)')"));
        // FLOAT token: decimal number with optional exponent.
        tokenDefs.add(new TokenDefinition(TokenType.FLOAT, "([0-9]+\\.[0-9]+)"));
        tokenDefs.add(new TokenDefinition(TokenType.INTEGER, "([0-9]+)"));
        tokenDefs.add(new TokenDefinition(TokenType.BOOLEAN, "(true|false)"));
        // OPERATOR now includes ==, +, -, *, /, %, ^, and =.
        tokenDefs.add(new TokenDefinition(TokenType.OPERATOR, "(\\+|\\-|\\*|/|%|\\^)"));
        tokenDefs.add(new TokenDefinition(TokenType.PUNCTUATION, "(\\{|\\}|\\(|\\)|\\[|\\]|;|,|\\.|:)"));
        tokenDefs.add(new TokenDefinition(TokenType.IDENTIFIER, "([a-z]+)"));

        // Compile token definitions and only keep those that compile successfully.
        List<TokenDefinition> compiledTokenDefs = new ArrayList<>();
        for (TokenDefinition def : tokenDefs) {
            try {
                def.compile();
                compiledTokenDefs.add(def);
            } catch (Exception e) {
                System.err.println("Error compiling token pattern for " + def.type + ": " + e.getMessage());
            }
        }
        tokenDefs = compiledTokenDefs;

        // Display DFA transition tables.
        for (TokenDefinition def : tokenDefs) {
            if (def.dfa != null) {
                System.out.println("DFA for " + def.type + " with pattern " + def.pattern);
                def.dfa.displayTransitionTable();
                System.out.println("Total DFA states: " + def.dfa.states.size());
                System.out.println("----------");
            }
        }

        // Sample source code with extra spaces, multi-line comment, arithmetic operations, and scope.
        String sourceCode = "int main()  \n"
                + "   int x = 0;  \n"
                + "   bool y = 0;  \n"
                + "   // multi-line \n comment */  \n"
                + "   {   bool l = true;  \n"
                + "       int a = 0;  \n"
                + "       x = x + y * a - 3 % 2 ^ 2;  \n"
                + "       return 0;  \n"
                + "   }";

        ErrorHandler errorHandler = new ErrorHandler();
        Lexer lexer = new Lexer(sourceCode, tokenDefs, errorHandler);
        List<Token> tokens = lexer.tokenize();

        System.out.println("Tokens:");
        for (Token token : tokens) {
            System.out.println(token);
        }

        // Scope management: process tokens to simulate declarations and scope changes.
        ScopeManager scopeManager = new ScopeManager();
        int memoryAddress = 1000;
        for (int i = 0; i < tokens.size(); i++) {
            Token token = tokens.get(i);
            // Change scope when encountering '{' or '}' punctuation.
            if (token.type == TokenType.PUNCTUATION) {
                if (token.lexeme.equals("{")) {
                    scopeManager.pushScope();
                } else if (token.lexeme.equals("}")) {
                    scopeManager.popScope();
                }
            }
            // Simple declaration: if KEYWORDS token followed by IDENTIFIER, add entry.
            if (token.type == TokenType.KEYWORDS && i + 1 < tokens.size()) {
                Token next = tokens.get(i + 1);
                if (next.type == TokenType.IDENTIFIER) {
                    scopeManager.addEntry(next.lexeme, token.lexeme, memoryAddress);
                    memoryAddress += 4;
                }
            }
        }

        // Display all scopes.
        scopeManager.displayScopes();

        if (errorHandler.hasErrors()) {
            errorHandler.displayErrors();
        }
    }
}
