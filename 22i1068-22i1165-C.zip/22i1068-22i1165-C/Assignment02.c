// C program to calculate First, Follow sets and construct a parsing table
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

// Functions to calculate Follow
void followfirst(char, int, int);
void follow(char c);

// Function to calculate First
void findfirst(char, int, int);

// Function to create parsing table
void create_parsing_table();

// Function to read grammar from file
void read_grammar_from_file(const char* filename);

int count = 0;
int n = 0;

// Stores the final result of the First Sets
char calc_first[10][100];

// Stores the final result of the Follow Sets
char calc_follow[10][100];
int m = 0;

// Stores the production rules
char production[50][10]; // Increased size to handle more rules
char f[10], first[10];
int k;
char ck;
int e;

// For parsing table
char terminals[10];
int terminals_count = 0;
char non_terminals[10];
int non_terminals_count = 0;
char parsing_table[10][10][10]; // [non_terminal][terminal][production]

// Map to store non-terminal substitutions (for T' to Y style replacements)
char nt_map[26][2]; // [index] = {original, replacement}
int nt_map_count = 0;

// Function to check if a character is a terminal
int is_terminal(char c) {
    if (!isupper(c) && c != '#')
        return 1;
    return 0;
}

// Function to add a character to a string if it's not already present
void add_char_to_array(char *arr, char c, int *count) {
    for (int i = 0; i < *count; i++) {
        if (arr[i] == c)
            return;
    }
    arr[(*count)++] = c;
}

// Function to get the replacement for a non-terminal with apostrophe
char get_nt_replacement(char c) {
    // Start with Available non-terminals from X to Z
    static char available = 'X';
    
    // Check if we already have a replacement
    for (int i = 0; i < nt_map_count; i++) {
        if (nt_map[i][0] == c) {
            return nt_map[i][1];
        }
    }
    
    // If not, create a new replacement
    nt_map[nt_map_count][0] = c;
    nt_map[nt_map_count][1] = available;
    nt_map_count++;
    
    return available++;
}

// Function to remove spaces from a string
void remove_spaces(char* str) {
    char* i = str;
    char* j = str;
    
    while (*j != '\0') {
        if (*j != ' ' && *j != '\t') {
            *i = *j;
            i++;
        }
        j++;
    }
    *i = '\0';
}

// Function to read grammar from file
void read_grammar_from_file(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file: %s\n", filename);
        exit(1);
    }
    
    char line[100];
    char processed_line[100];
    char temp_production[50][10]; // Temporary storage for productions
    int temp_count = 0;
    
    while (fgets(line, sizeof(line), file)) {
        if (strlen(line) <= 1) continue; // Skip empty lines
        
        // Remove newline character
        line[strcspn(line, "\n")] = '\0';
        
        // Process the line
        strcpy(processed_line, line);
        remove_spaces(processed_line);
        
        // Find the arrow position
        char* arrow_pos = strstr(processed_line, "->");
        if (arrow_pos == NULL) {
            continue; // Skip if not a production rule
        }
        
        // Extract left and right sides
        char left_side[10] = {0};
        char right_side[90] = {0};
        
        int left_len = arrow_pos - processed_line;
        strncpy(left_side, processed_line, left_len);
        left_side[left_len] = '\0';
        
        strcpy(right_side, arrow_pos + 2); // Skip ->
        
        // Handle non-terminal with apostrophe (T' becomes a new non-terminal)
        char nt = left_side[0];
        if (left_side[1] == '\'') {
            nt = get_nt_replacement(nt);
        }
        
        // Split by |
        char* token = strtok(right_side, "|");
        while (token != NULL) {
            strcpy(temp_production[temp_count], "");
            
            // Create the production
            temp_production[temp_count][0] = nt;
            temp_production[temp_count][1] = '=';
            
            // Process right side
            int j = 2;
            int i = 0;
            while (token[i] != '\0') {
                if (token[i] == '#') {
                    // Handle epsilon
                    temp_production[temp_count][j++] = '#';
                    i++;
                } else if (isupper(token[i]) && token[i+1] == '\'') {
                    // Handle T' in the right side
                    char replacement = get_nt_replacement(token[i]);
                    temp_production[temp_count][j++] = replacement;
                    i += 2; // Skip the apostrophe
                } else if (isupper(token[i])) {
                    // Handle non-terminal
                    temp_production[temp_count][j++] = token[i];
                    i++;
                } else {
                    // Handle terminal (could be multi-character)
                    while (token[i] != '\0' && !isupper(token[i]) && token[i] != '|') {
                        temp_production[temp_count][j++] = token[i];
                        i++;
                    }
                }
            }
            temp_production[temp_count][j] = '\0';
            temp_count++;
            
            token = strtok(NULL, "|");
        }
    }
    
    fclose(file);
    
    // Copy the temporary productions to the actual productions
    count = temp_count;
    for (int i = 0; i < temp_count; i++) {
        strcpy(production[i], temp_production[i]);
    }
    
    // Debug: Print the processed grammar
    printf("\nProcessed Grammar:\n");
    for (int i = 0; i < count; i++) {
        printf("%s\n", production[i]);
    }
    printf("\nNon-terminal Mappings:\n");
    for (int i = 0; i < nt_map_count; i++) {
        printf("%c' => %c\n", nt_map[i][0], nt_map[i][1]);
    }
    printf("\n");
}

// Function to perform left factoring
void perform_left_factoring() {
    int i, j;
    char common_prefix[10];
    int prefix_len;
    char new_non_terminal;
    char temp_prod[50][10];
    int temp_count = 0;
    
    for (i = 0; i < count; i++) {
        char* rhs = strdup(production[i] + 2); // Skip lhs and '='
        char* first_alt = strtok(rhs, "|");
        char* second_alt = strtok(NULL, "|");
        
        if (second_alt) {
            // Find common prefix
            prefix_len = 0;
            while (first_alt[prefix_len] && second_alt[prefix_len] && 
                   first_alt[prefix_len] == second_alt[prefix_len]) {
                common_prefix[prefix_len] = first_alt[prefix_len];
                prefix_len++;
            }
            common_prefix[prefix_len] = '\0';
            
            if (prefix_len > 0) {
                // Create new non-terminal
                new_non_terminal = get_nt_replacement(production[i][0]);
                
                // Modify original production
                sprintf(temp_prod[temp_count], "%c=%s%c", 
                        production[i][0], common_prefix, new_non_terminal);
                temp_count++;
                
                // Add new production for remaining part of first alternative
                if (first_alt[prefix_len]) {
                    sprintf(temp_prod[temp_count], "%c=%s", 
                            new_non_terminal, first_alt + prefix_len);
                    temp_count++;
                }
                
                // Add new production for remaining part of second alternative
                if (second_alt[prefix_len]) {
                    sprintf(temp_prod[temp_count], "%c=%s", 
                            new_non_terminal, second_alt + prefix_len);
                    temp_count++;
                }
                
                // Add epsilon production if needed
                if (!first_alt[prefix_len] || !second_alt[prefix_len]) {
                    sprintf(temp_prod[temp_count], "%c=#", new_non_terminal);
                    temp_count++;
                }
            } else {
                strcpy(temp_prod[temp_count], production[i]);
                temp_count++;
            }
        } else {
            strcpy(temp_prod[temp_count], production[i]);
            temp_count++;
        }
        
        free(rhs);
    }
    
    // Update productions
    count = temp_count;
    for (i = 0; i < count; i++) {
        strcpy(production[i], temp_prod[i]);
    }
}

// Function to eliminate immediate left recursion
void eliminate_immediate_left_recursion(int prod_index) {
    char nt = production[prod_index][0];
    char alpha[10] = {0};
    char beta[10] = {0};
    char new_nt = get_nt_replacement(nt);
    char temp_prod[50][10];
    int temp_count = 0;
    
    char* rhs = strdup(production[prod_index] + 2);
    char* token = strtok(rhs, "|");
    
    while (token) {
        if (token[0] == nt) {
            strcpy(alpha, token + 1);
        } else {
            strcpy(beta, token);
        }
        token = strtok(NULL, "|");
    }
    
    if (alpha[0] && beta[0]) {
        // A -> βA'
        sprintf(temp_prod[temp_count], "%c=%s%c", nt, beta, new_nt);
        temp_count++;
        
        // A' -> αA' | ε
        sprintf(temp_prod[temp_count], "%c=%s%c|#", new_nt, alpha, new_nt);
        temp_count++;
        
        // Update productions
        for (int i = 0; i < count; i++) {
            if (i != prod_index) {
                strcpy(temp_prod[temp_count], production[i]);
                temp_count++;
            }
        }
        
        count = temp_count;
        for (int i = 0; i < count; i++) {
            strcpy(production[i], temp_prod[i]);
        }
    }
    
    free(rhs);
}

// Function to remove left recursion
void remove_left_recursion() {
    int i, j;
    bool changed;
    
    do {
        changed = false;
        for (i = 0; i < count; i++) {
            char nt = production[i][0];
            
            // Check for immediate left recursion
            char* rhs = strdup(production[i] + 2);
            char* token = strtok(rhs, "|");
            bool has_recursion = false;
            
            while (token) {
                if (token[0] == nt) {
                    has_recursion = true;
                    break;
                }
                token = strtok(NULL, "|");
            }
            
            if (has_recursion) {
                eliminate_immediate_left_recursion(i);
                changed = true;
            }
            
            free(rhs);
        }
    } while (changed);
}

// Function to check if a string is a terminal
int is_terminal_string(const char* str) {
    if (str[0] == '\0') return 0;
    if (str[0] == '#') return 1;  // Epsilon is a terminal
    if (!isupper(str[0])) return 1;  // If first char is not uppercase, it's a terminal
    return 0;
}

// Function to identify terminals and non-terminals
void identify_symbols() {
    terminals_count = 0;
    non_terminals_count = 0;
    
    for (int i = 0; i < count; i++) {
        // Add non-terminal from LHS
        char nt = production[i][0];
        add_char_to_array(non_terminals, nt, &non_terminals_count);
        
        // Process RHS
        char* rhs = strdup(production[i] + 2);
        char* token = strtok(rhs, "|");
        
        while (token != NULL) {
            int j = 0;
            while (token[j] != '\0') {
                if (token[j] == '#') {
                    add_char_to_array(terminals, '#', &terminals_count);
                    j++;
                } else if (isupper(token[j])) {
                    if (token[j+1] == '\'') {
                        // Skip the apostrophe
                        j += 2;
                    } else {
                        j++;
                    }
                } else {
                    // Handle multi-character terminals
                    char terminal[10] = {0};
                    int k = 0;
                    while (token[j] != '\0' && !isupper(token[j]) && token[j] != '|') {
                        terminal[k++] = token[j++];
                    }
                    if (k > 0) {
                        add_char_to_array(terminals, terminal[0], &terminals_count);
                    }
                }
            }
            token = strtok(NULL, "|");
        }
        
        free(rhs);
    }
    
    // Add $ to terminals for end marker
    add_char_to_array(terminals, '$', &terminals_count);
}

int main() {
    int jm = 0;
    int km = 0;
    int i, choice;
    char c, ch;
    
    // Read grammar from file
    char filename[100];
    printf("Enter the grammar file name: ");
    scanf("%s", filename);
    read_grammar_from_file(filename);
    
    // Perform left factoring
    printf("\nPerforming Left Factoring...\n");
    perform_left_factoring();
    printf("\nGrammar after Left Factoring:\n");
    for (i = 0; i < count; i++) {
        printf("%s\n", production[i]);
    }
    
    // Remove left recursion
    printf("\nRemoving Left Recursion...\n");
    remove_left_recursion();
    printf("\nGrammar after Left Recursion Removal:\n");
    for (i = 0; i < count; i++) {
        printf("%s\n", production[i]);
    }
    
    // Identify terminals and non-terminals
    identify_symbols();
    
    int kay;
    char done[100];  // Assuming max 100 productions
    int ptr = -1;
    
    // Initializing the calc_first array
    for (k = 0; k < count; k++) {
        for (kay = 0; kay < 100; kay++) {
            calc_first[k][kay] = '!';
        }
    }
    int point1 = 0, point2, x;
    
    printf("FIRST SETS:\n");
    printf("===========\n");
    for (k = 0; k < count; k++) {
        c = production[k][0];
        point2 = 0;
        x = 0;
        
        // Checking if First of c has already been calculated
        for (kay = 0; kay <= ptr; kay++)
            if (c == done[kay])
                x = 1;
                
        if (x == 1)
            continue;
        
        // Function call     
        findfirst(c, 0, 0);
        ptr += 1;
        
        // Adding c to the calculated list
        done[ptr] = c;
        printf(" First(%c) = { ", c);
        calc_first[point1][point2++] = c;
        
        // Printing the First Sets of the grammar
        for (i = 0 + jm; i < n; i++) {
            int lark = 0, chk = 0;
            
            for (lark = 0; lark < point2; lark++) {
                if (first[i] == calc_first[point1][lark]) {
                    chk = 1;
                    break;
                }
            }
            if (chk == 0) {
                printf("%c, ", first[i]);
                calc_first[point1][point2++] = first[i];
            }
        }
        printf("}\n");
        jm = n;
        point1++;
    }
    
    printf("\nFOLLOW SETS:\n");
    printf("============\n");
    char donee[100];  // Using fixed-size array instead of variable-length array
    ptr = -1;
    
    // Initializing the calc_follow array
    for (k = 0; k < count; k++) {
        for (kay = 0; kay < 100; kay++) {
            calc_follow[k][kay] = '!';
        }
    }
    point1 = 0;
    int land = 0;
    for (e = 0; e < count; e++) {
        ck = production[e][0];
        point2 = 0;
        x = 0;
        
        // Checking if Follow of ck has already been calculated
        for (kay = 0; kay <= ptr; kay++)
            if (ck == donee[kay])
                x = 1;
                
        if (x == 1)
            continue;
        land += 1;
        
        // Function call
        follow(ck);
        ptr += 1;
        
        // Adding ck to the calculated list
        donee[ptr] = ck;
        printf(" Follow(%c) = { ", ck);
        calc_follow[point1][point2++] = ck;
        
        // Printing the Follow Sets of the grammar
        for (i = 0 + km; i < m; i++) {
            int lark = 0, chk = 0;
            for (lark = 0; lark < point2; lark++) {
                if (f[i] == calc_follow[point1][lark]) {
                    chk = 1;
                    break;
                }
            }
            if (chk == 0) {
                printf("%c, ", f[i]);
                calc_follow[point1][point2++] = f[i];
            }
        }
        printf("}\n");
        km = m;
        point1++;
    }
    
    // Create and display parsing table
    create_parsing_table();
    
    printf("\nPARSING TABLE:\n");
    printf("==============\n");
    
    // Print terminal headers
    printf("   | ");
    for (i = 0; i < terminals_count; i++) {
        printf("%c | ", terminals[i]);
    }
    printf("\n");
    
    // Print separator line
    printf("---+");
    for (i = 0; i < terminals_count; i++) {
        printf("---+");
    }
    printf("\n");
    
    // Print table contents
    for (i = 0; i < non_terminals_count; i++) {
        printf(" %c | ", non_terminals[i]);
        for (int j = 0; j < terminals_count; j++) {
            if (parsing_table[i][j][0] != '\0') {
                printf("%s | ", parsing_table[i][j]);
            } else {
                printf("   | ");
            }
        }
        printf("\n");
    }
    
    return 0;
}

// Function to create parsing table
void create_parsing_table() {
    // Initialize table to empty
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            parsing_table[i][j][0] = '\0';
        }
    }
    
    // For each production rule
    for (int i = 0; i < count; i++) {
        char nt = production[i][0];
        char rhs[10];
        strcpy(rhs, &production[i][2]);
        
        // Find index of non-terminal
        int nt_index = 0;
        while (nt_index < non_terminals_count && non_terminals[nt_index] != nt) {
            nt_index++;
        }
        
        // If RHS starts with terminal, add production to table
        if (is_terminal(rhs[0]) && rhs[0] != '#') {
            // Find index of terminal
            int t_index = 0;
            while (t_index < terminals_count && terminals[t_index] != rhs[0]) {
                t_index++;
            }
            // Add production to table
            strcpy(parsing_table[nt_index][t_index], rhs);
        } 
        // If RHS starts with non-terminal, add production for each First(RHS[0])
        else if (isupper(rhs[0])) {
            int first_index = 0;
            while (first_index < count && calc_first[first_index][0] != rhs[0]) {
                first_index++;
            }
            
            // For each terminal in First(RHS[0])
            for (int j = 1; calc_first[first_index][j] != '!'; j++) {
                if (calc_first[first_index][j] != '#') {
                    // Find index of terminal
                    int t_index = 0;
                    while (t_index < terminals_count && terminals[t_index] != calc_first[first_index][j]) {
                        t_index++;
                    }
                    // Add production to table
                    strcpy(parsing_table[nt_index][t_index], rhs);
                }
            }
            
            // If First(RHS[0]) contains epsilon, add production for each Follow(NT)
            for (int j = 1; calc_first[first_index][j] != '!'; j++) {
                if (calc_first[first_index][j] == '#') {
                    int follow_index = 0;
                    while (follow_index < count && calc_follow[follow_index][0] != nt) {
                        follow_index++;
                    }
                    
                    // For each terminal in Follow(NT)
                    for (int l = 1; calc_follow[follow_index][l] != '!'; l++) {
                        // Find index of terminal
                        int t_index = 0;
                        while (t_index < terminals_count && terminals[t_index] != calc_follow[follow_index][l]) {
                            t_index++;
                        }
                        // Add production to table
                        strcpy(parsing_table[nt_index][t_index], rhs);
                    }
                }
            }
        }
        // If RHS is epsilon, add production for each Follow(NT)
        else if (rhs[0] == '#') {
            int follow_index = 0;
            while (follow_index < count && calc_follow[follow_index][0] != nt) {
                follow_index++;
            }
            
            // For each terminal in Follow(NT)
            for (int j = 1; calc_follow[follow_index][j] != '!'; j++) {
                // Find index of terminal
                int t_index = 0;
                while (t_index < terminals_count && terminals[t_index] != calc_follow[follow_index][j]) {
                    t_index++;
                }
                // Add production to table
                strcpy(parsing_table[nt_index][t_index], "#");
            }
        }
    }
}

void follow(char c) {
    int i, j;
    
    // Adding "$" to the follow set of the start symbol
    if (production[0][0] == c) {
        f[m++] = '$';
    }
    for (i = 0; i < count; i++) {
        for (j = 2; j < 10; j++) {
            if (production[i][j] == c) {
                if (production[i][j+1] != '\0') {
                    // Calculate the first of the next
                    // Non-Terminal in the production
                    followfirst(production[i][j+1], i, (j+2));
                }
                
                if (production[i][j+1] == '\0' && c != production[i][0]) {
                    // Calculate the follow of the Non-Terminal
                    // in the L.H.S. of the production
                    follow(production[i][0]);
                }
            }
        }
    }
}

void findfirst(char c, int q1, int q2) {
    int j;
    
    // The case where we encounter a Terminal
    if (!(isupper(c))) {
        first[n++] = c;
    }
    for (j = 0; j < count; j++) {
        if (production[j][0] == c) {
            if (production[j][2] == '#') {
                if (production[q1][q2] == '\0')
                    first[n++] = '#';
                else if (production[q1][q2] != '\0'
                        && (q1 != 0 || q2 != 0)) {
                    // Recursion to calculate First of New
                    // Non-Terminal we encounter after epsilon
                    findfirst(production[q1][q2], q1, (q2+1));
                }
                else
                    first[n++] = '#';
            }
            else if (!isupper(production[j][2])) {
                first[n++] = production[j][2];
            }
            else {
                // Recursion to calculate First of
                // New Non-Terminal we encounter
                // at the beginning
                findfirst(production[j][2], j, 3);
            }
        }
    }
}

void followfirst(char c, int c1, int c2) {
    int k;
    
    // The case where we encounter a Terminal
    if (!(isupper(c)))
        f[m++] = c;
    else {
        int i = 0, j = 1;
        for (i = 0; i < count; i++) {
            if (calc_first[i][0] == c)
                break;
        }
        
        // Including the First set of the
        // Non-Terminal in the Follow of
        // the original query
        while (calc_first[i][j] != '!') {
            if (calc_first[i][j] != '#') {
                f[m++] = calc_first[i][j];
            }
            else {
                if (production[c1][c2] == '\0') {
                    // Case where we reach the
                    // end of a production
                    follow(production[c1][0]);
                }
                else {
                    // Recursion to the next symbol
                    // in case we encounter a "#"
                    followfirst(production[c1][c2], c1, c2+1);
                }
            }
            j++;
        }
    }
}
